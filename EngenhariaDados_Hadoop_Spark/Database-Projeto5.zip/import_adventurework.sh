mysql -u root -p < ./AWBackup.sql
